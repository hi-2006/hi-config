#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
#parse("File Header.java")
/**
* @author Created by Joe on ${DATE}.
*/
public enum ${NAME} {
}
